#!/usr/bin/env python3
"""
Renders Pip's voice (small formant synthesizer, no external TTS needed) to Minecraft-ready mono .ogg files:
    sounds/pip/hey.ogg            "Hey, I am Pip, thanks for feeding me that!"   (played when Pip wakes up)
    sounds/pip/talk1..3.ogg       short chirpy babble (played when Pip says other things in chat)

    python3 tools/make_pip_voice.py             # needs numpy, scipy and ffmpeg (with libvorbis)

Want a different voice? Change BASE_F0 (higher = squeakier) or replace the .ogg files with your own
recordings / TTS output - just keep the same file names (mono, 22050-44100 Hz, Ogg Vorbis).
"""
import os
import subprocess
import tempfile

import numpy as np
from scipy.io import wavfile

SR = 22050
BASE_F0 = 370.0          # Hz. ~220 = normal woman, ~370 = "medium-high & friendly", 500+ = chipmunk
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources",
                   "assets", "piphorror", "sounds", "pip")

# ---- phoneme table: (F1, F2, F3), duration(s), kind ------------------------------------------
V = {  # vowels (child/female-ish formants)
    "IY": ((330, 2800, 3400), 0.14), "IH": ((440, 2500, 3200), 0.11), "EH": ((620, 2300, 3100), 0.12),
    "AE": ((880, 2100, 3000), 0.16), "AH": ((800, 1400, 2900), 0.12), "AO": ((620, 950, 2800), 0.15),
    "UW": ((350, 1000, 2800), 0.14), "EY": ((520, 2250, 3100), 0.20), "AY": ((850, 1500, 2900), 0.22),
    "AA": ((900, 1300, 2900), 0.15), "OW": ((540, 1000, 2800), 0.18),
}
EY_END = (340, 2700, 3300)
AY_END = (420, 2400, 3200)
OW_END = (380, 900, 2700)

# consonants: kind, duration, params
C = {
    "HH": ("asp", 0.07), "M": ("nasal", 0.08, (260, 1100, 2500)), "N": ("nasal", 0.07, (260, 1700, 2800)),
    "NG": ("nasal", 0.08, (260, 1300, 2600)), "P": ("stop", 0.09, 1200), "T": ("stop", 0.08, 3500),
    "K": ("stop", 0.09, 2200), "B": ("vstop", 0.06, 900), "D": ("vstop", 0.05, 2800), "S": ("fric", 0.11, 7000),
    "F": ("fric", 0.09, 4500), "TH": ("fric", 0.08, 5000), "DH": ("vfric", 0.05, 4000), "R": ("approx", 0.07, (420, 1300, 1700)),
    "Y": ("approx", 0.06, (300, 2300, 3100)), "W": ("approx", 0.06, (330, 800, 2500)),
}


class Resonator:
    def __init__(self):
        self.y1 = self.y2 = 0.0

    def step(self, x, f, bw):
        r = np.exp(-np.pi * bw / SR)
        c = -r * r
        b = 2 * r * np.cos(2 * np.pi * f / SR)
        a = 1 - b - c
        y = a * x + b * self.y1 + c * self.y2
        self.y2, self.y1 = self.y1, y
        return y


def tokens_to_frames(tokens, f0_curve):
    """tokens: list of phoneme strings (or 'SIL:0.1'). returns list of per-5ms frame dicts."""
    frames = []
    HOP = int(SR * 0.005)
    prev_form = (500, 1500, 2500)
    for tok in tokens:
        if tok.startswith("SIL"):
            n = int(float(tok.split(":")[1]) / 0.005)
            frames += [dict(av=0, ah=0, af=0, fc=3000, form=prev_form, nasal=0)] * n
            continue
        if tok in V:
            form, dur = V[tok]
            n = int(dur / 0.005)
            end = {"EY": EY_END, "AY": AY_END, "OW": OW_END}.get(tok, form)
            for i in range(n):
                a = i / max(1, n - 1)
                fr = tuple(form[k] * (1 - a) + end[k] * a for k in range(3))
                env = min(1.0, i / 3.0) * min(1.0, (n - i) / 3.0 + 0.35)
                frames.append(dict(av=1.0 * env, ah=0.02, af=0, fc=3000, form=fr, nasal=0))
                prev_form = fr
            continue
        c = C[tok]
        kind, dur = c[0], c[1]
        n = int(dur / 0.005)
        if kind == "asp":
            frames += [dict(av=0, ah=0.5, af=0, fc=3000, form=prev_form, nasal=0)] * n
        elif kind == "nasal":
            f = c[2]
            frames += [dict(av=0.55, ah=0, af=0, fc=3000, form=f, nasal=1)] * n
            prev_form = f
        elif kind in ("stop", "vstop"):
            closure = max(2, n // 2)
            frames += [dict(av=0.25 if kind == "vstop" else 0, ah=0, af=0, fc=3000, form=prev_form, nasal=0)] * closure
            frames += [dict(av=0.2 if kind == "vstop" else 0, ah=0, af=0.9 if kind == "stop" else 0.5, fc=c[2],
                            form=prev_form, nasal=0)] * (n - closure)
        elif kind in ("fric", "vfric"):
            frames += [dict(av=0.35 if kind == "vfric" else 0, ah=0, af=0.7 if kind == "fric" else 0.35, fc=c[2],
                            form=prev_form, nasal=0)] * n
        elif kind == "approx":
            f = c[2]
            frames += [dict(av=0.7, ah=0, af=0, fc=3000, form=f, nasal=0)] * n
            prev_form = f
    return frames


def synth(tokens, f0_scale=1.0, seed=1, contour=None):
    rng = np.random.default_rng(seed)
    frames = tokens_to_frames(tokens, None)
    HOP = int(SR * 0.005)
    total = len(frames) * HOP
    out = np.zeros(total)
    res_f = [Resonator() for _ in range(3)]
    res_n = Resonator()
    res_fric = Resonator()
    res_fric2 = Resonator()
    phase = 0.0
    smooth = [np.array(frames[0]["form"], float)]
    prev_glot = 0.0
    n_frames = len(frames)
    for fi, fr in enumerate(frames):
        pos = fi / max(1, n_frames - 1)
        # intonation contour: rises then falls, with a little vibrato = "happy"
        c = contour(pos) if contour else 1.0
        f0 = BASE_F0 * f0_scale * c * (1 + 0.012 * np.sin(2 * np.pi * 6.0 * fi * 0.005))
        target = np.array(fr["form"], float)
        for k in range(HOP):
            smooth[0] += (target - smooth[0]) * 0.012      # formant glide between phonemes
            i = fi * HOP + k
            phase += f0 / SR
            if phase >= 1.0:
                phase -= 1.0
            # glottal source: smoothed sawtooth-ish pulse
            glot = (1 - phase) ** 2 * 1.0 - 0.33
            src = fr["av"] * glot + fr["ah"] * rng.standard_normal() * 0.6
            y = 0.0
            if fr["nasal"]:
                y = res_n.step(src, 250, 100) * 1.6 + res_f[1].step(src, smooth[0][1], 250) * 0.3
            else:
                s1 = res_f[0].step(src, smooth[0][0], 90)
                s2 = res_f[1].step(s1, smooth[0][1], 140)
                s3 = res_f[2].step(s2, smooth[0][2], 220)
                y = s3 * 0.9
            if fr["af"] > 0:
                nz = rng.standard_normal()
                fcen = fr["fc"]
                fz = res_fric.step(nz, fcen, max(600, fcen * 0.35))
                fz = res_fric2.step(fz, fcen * 1.1, max(800, fcen * 0.4))
                y += fz * fr["af"] * 0.5
            out[i] = y
    # gentle high-pass + normalise + fades
    out = np.append(np.diff(out, prepend=out[0]) * 0.6 + out * 0.4, np.zeros(int(0.05 * SR)))
    out /= max(1e-6, np.abs(out).max())
    out *= 0.85
    fade = int(0.01 * SR)
    out[:fade] *= np.linspace(0, 1, fade)
    out[-fade:] *= np.linspace(1, 0, fade)
    return out


def to_ogg(samples, name):
    os.makedirs(OUT, exist_ok=True)
    pcm = (np.clip(samples, -1, 1) * 32767).astype(np.int16)
    with tempfile.TemporaryDirectory() as d:
        wav = os.path.join(d, "x.wav")
        wavfile.write(wav, SR, pcm)
        path = os.path.join(OUT, name + ".ogg")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "5", path], check=True)
    print("wrote", path, "%.2fs" % (len(samples) / SR))


def bell(pos):
    return 1.0 + 0.16 * np.sin(np.pi * min(1.0, pos * 1.1))


def main():
    # "Hey, I am Pip, thanks for feeding me that!"
    hey = [
        "HH", "EY", "SIL:0.10",
        "AY", "SIL:0.03", "AE", "M", "SIL:0.07",
        "P", "IH", "P", "SIL:0.12",
        "TH", "AE", "NG", "K", "S", "SIL:0.03", "F", "AO", "R", "SIL:0.03",
        "F", "IY", "D", "IH", "NG", "SIL:0.03", "M", "IY", "SIL:0.03", "DH", "AE", "T",
    ]

    def hey_contour(pos):
        base = 1.0 + 0.10 * np.sin(np.pi * pos * 3.3)       # bouncy
        if pos < 0.10:
            base += 0.20 * (1 - pos / 0.10)                  # excited "Hey!"
        if pos > 0.86:
            base -= 0.15 * (pos - 0.86) / 0.14               # settle down at the end
        return base

    to_ogg(synth(hey, contour=hey_contour, seed=3), "hey")

    babbles = [
        ["M", "IY", "P", "IH", "P", "SIL:0.04", "AY", "SIL:0.05", "Y", "AE", "P"],
        ["HH", "EH", "Y", "SIL:0.05", "B", "AH", "B", "IY", "SIL:0.05", "N", "IH", "P"],
        ["Y", "AY", "SIL:0.04", "P", "IY", "P", "SIL:0.05", "M", "AH", "M", "IY", "AA"],
    ]
    for i, b in enumerate(babbles, 1):
        to_ogg(synth(b, f0_scale=1.0 + 0.04 * i, contour=bell, seed=10 + i), "talk%d" % i)


if __name__ == "__main__":
    main()
