#!/usr/bin/env python3
"""
Offline preview of Pip's rig. Reproduces GeckoLib's maths (pivot -> rotate Z,Y,X -> scale -> -pivot, x mirrored)
on the real OBJ mesh and textures, so you can check poses without launching Minecraft.

    python3 tools/preview_rig.py                       # contact sheet of every animation -> tools/preview/
    python3 tools/preview_rig.py animation.pip.lookout_listen 0.6   # one animation at t=0.6s

Needs: numpy, matplotlib, pillow
"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "piphorror")

# Must match PipObjModel.java
PART_TO_BONE = {"body_mesh": "body"}
for p in ["head_mesh", "cheek_L_mesh", "cheek_R_mesh", "nose_mesh", "tear_L_mesh", "tear_R_mesh"]:
    PART_TO_BONE[p] = "head"
for p in ["lip_L_mesh", "lip_R_mesh", "mouth_inside_mesh"]:
    PART_TO_BONE[p] = "mouth"
for s in "LR":
    PART_TO_BONE["eyeball_" + s] = "eyeball_" + s
    PART_TO_BONE["pupil_" + s] = "pupil_dot_" + s
    PART_TO_BONE["eyelid_" + s] = "eyelid_" + s
    PART_TO_BONE["arm_%s_mesh" % s] = "arm_" + s
    for q in ["palm_%s_mesh" % s] + ["finger_%s%d_mesh" % (s, i) for i in (1, 2, 3)]:
        PART_TO_BONE[q] = "paw_" + s


def load_obj():
    verts, uvs, faces = [], [], []
    bone = "body"
    for line in open(os.path.join(ASSETS, "models", "entity", "friendly_pip.obj")):
        t = line.split()
        if not t:
            continue
        if t[0] == "v":
            verts.append([float(x) for x in t[1:4]])
        elif t[0] == "vt":
            uvs.append([float(t[1]), float(t[2])])
        elif t[0] in ("o", "g"):
            bone = PART_TO_BONE.get(t[1], "body")
        elif t[0] == "f":
            idx = [tuple(int(i) if i else 0 for i in p.split("/")[:2]) for p in t[1:]]
            faces.append((bone, [(a - 1, b - 1) for a, b in idx]))
    return np.array(verts), np.array(uvs), faces


def load_geo():
    g = json.load(open(os.path.join(ASSETS, "geo", "friendly_pip.geo.json")))["minecraft:geometry"][0]["bones"]
    return {b["name"]: {"parent": b.get("parent"), "pivot": np.array([-b["pivot"][0], b["pivot"][1], b["pivot"][2]]) / 16.0} for b in g}


def interp(keys, t):
    ts = sorted(keys, key=float)
    vals = [np.array(keys[k] if isinstance(keys[k], list) else keys[k]["post"], float) for k in ts]
    tf = [float(k) for k in ts]
    if t <= tf[0]:
        return vals[0]
    for i in range(1, len(tf)):
        if t <= tf[i]:
            a = (t - tf[i - 1]) / max(1e-9, tf[i] - tf[i - 1])
            return vals[i - 1] * (1 - a) + vals[i] * a
    return vals[-1]


def rot_zyx(rx, ry, rz):
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def bone_matrices(geo, anim, t, overrides=None):
    """Return {bone: 4x4 matrix} using GeckoLib's order. overrides: {bone: {'rot':(x,y,z baked radians added), 'scale':(..)}}"""
    overrides = overrides or {}
    cache = {}

    def mat(name):
        if name in cache:
            return cache[name]
        b = geo[name]
        parent = mat(b["parent"]) if b["parent"] else np.eye(4)
        data = (anim or {}).get("bones", {}).get(name, {})
        pos = interp(data["position"], t) if "position" in data else np.zeros(3)
        rot = interp(data["rotation"], t) if "rotation" in data else np.zeros(3)
        scl = interp(data["scale"], t) if "scale" in data else np.ones(3)
        ov = overrides.get(name, {})
        # GeckoLib: baked rotation = (-x, -y, +z) radians, position x mirrored
        brx, bry, brz = -math.radians(rot[0]), -math.radians(rot[1]), math.radians(rot[2])
        if "rot" in ov:
            brx, bry, brz = brx + ov["rot"][0], bry + ov["rot"][1], brz + ov["rot"][2]
        if "scale" in ov:
            scl = np.array(ov["scale"], float)
        piv = b["pivot"]
        M = np.eye(4)
        M[:3, 3] = [-pos[0] / 16, pos[1] / 16, pos[2] / 16]
        T1 = np.eye(4); T1[:3, 3] = piv
        R = np.eye(4); R[:3, :3] = rot_zyx(brx, bry, brz)
        S = np.diag([scl[0], scl[1], scl[2], 1.0])
        T2 = np.eye(4); T2[:3, 3] = -piv
        cache[name] = parent @ M @ T1 @ R @ S @ T2
        return cache[name]

    for n in geo:
        mat(n)
    return cache


class Preview:
    def __init__(self):
        self.verts, self.uvs, self.faces = load_obj()
        self.geo = load_geo()
        self.tex = np.array(Image.open(os.path.join(ASSETS, "textures", "entity", "friendly_pip.png")).convert("RGB"))
        self.anims = json.load(open(os.path.join(ASSETS, "animations", "pip.animation.json")))["animations"]
        h, w = self.tex.shape[:2]
        cols = []
        for bone, f in self.faces:
            uv = np.mean([self.uvs[b] for _, b in f], axis=0)
            x = min(w - 1, max(0, int(uv[0] * w)))
            y = min(h - 1, max(0, int((1 - uv[1]) * h)))
            cols.append(self.tex[y, x] / 255.0)
        self.cols = np.array(cols)
        self.fbones = [b for b, _ in self.faces]
        self.fidx = [[a for a, _ in f] for _, f in self.faces]

    def pose(self, anim_name, t, overrides=None):
        anim = self.anims.get(anim_name)
        mats = bone_matrices(self.geo, anim, t, overrides)
        out = np.zeros_like(self.verts)
        # transform each vertex by the bone its face belongs to (vertices are not shared across parts)
        vb = {}
        for bone, idxs in zip(self.fbones, self.fidx):
            for i in idxs:
                vb[i] = bone
        for i, v in enumerate(self.verts):
            m = mats[vb.get(i, "body")]
            out[i] = (m @ np.append(v, 1.0))[:3]
        return out

    def draw(self, ax, anim_name, t, yaw_deg=25, overrides=None, title=None):
        P = self.pose(anim_name, t, overrides)
        a = math.radians(yaw_deg)
        # viewer sits in front of Pip (at -z). screen right = -x
        c, s = math.cos(a), math.sin(a)
        X = -(P[:, 0] * c + P[:, 2] * s)
        Z = -P[:, 0] * s + P[:, 2] * c  # larger = farther from the viewer
        Y = P[:, 1]
        polys, depth, colors = [], [], []
        for k, idxs in enumerate(self.fidx):
            polys.append([(X[i], Y[i]) for i in idxs])
            depth.append(np.mean([Z[i] for i in idxs]))
            colors.append(self.cols[k])
        order = np.argsort(depth)[::-1]
        pc = PolyCollection([polys[i] for i in order], facecolors=[colors[i] for i in order], edgecolors="none", linewidths=0)
        ax.add_collection(pc)
        ax.set_xlim(-0.6, 0.6)
        ax.set_ylim(-0.05, 1.05)
        ax.set_aspect("equal")
        ax.axhline(0, color="#665", lw=0.6)
        ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(title or "%s @ %.2fs" % (anim_name.replace("animation.pip.", ""), t), fontsize=8)


def contact_sheet(pv):
    out = os.path.join(HERE, "preview")
    os.makedirs(out, exist_ok=True)
    names = [n for n in pv.anims]
    samples = {}
    for n in names:
        L = pv.anims[n]["animation_length"]
        samples[n] = [0.0, L * 0.25, L * 0.5, L * 0.75] if pv.anims[n]["loop"] else [0.0, L * 0.35, L * 0.65, L * 0.95]
    cols = 4
    fig, axes = plt.subplots(len(names), cols, figsize=(cols * 2.4, len(names) * 2.5), facecolor="#bcd4ee")
    for r, n in enumerate(names):
        for c in range(cols):
            ax = axes[r][c]
            ax.set_facecolor("#bcd4ee")
            pv.draw(ax, n, samples[n][c])
    fig.tight_layout()
    path = os.path.join(out, "all_animations.png")
    fig.savefig(path, dpi=70)
    print("wrote", path)


if __name__ == "__main__":
    pv = Preview()
    if len(sys.argv) >= 2:
        name = sys.argv[1]
        t = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
        fig, axes = plt.subplots(1, 3, figsize=(9, 4), facecolor="#bcd4ee")
        for ax, yaw in zip(axes, (0, 35, 90)):
            ax.set_facecolor("#bcd4ee")
            pv.draw(ax, name, t, yaw)
        os.makedirs(os.path.join(HERE, "preview"), exist_ok=True)
        fig.savefig(os.path.join(HERE, "preview", "one.png"), dpi=80)
        print("wrote preview/one.png")
    else:
        contact_sheet(pv)
