package com.piphorror.mod.client.model;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Loads the Blockbench OBJ mesh of the friendly Pip and groups its triangles/quads by the
 * GeckoLib bone that should move them (see friendly_pip.geo.json).
 *
 * Output format: for every bone a flat float[] where each vertex is 8 floats
 * (x, y, z, u, v, nx, ny, nz) and every 4 vertices form one quad.
 * Triangles are written as a quad whose 4th vertex repeats the 3rd.
 */
public final class PipObjModel {
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final ResourceLocation MODEL =
        new ResourceLocation("piphorror", "models/entity/friendly_pip.obj");
    public static final int FLOATS_PER_VERTEX = 8;

    /** OBJ object name -> animation bone name (bones live in geo/friendly_pip.geo.json, built by tools/build_pip_rig.py). */
    private static final Map<String, String> PART_TO_BONE = new HashMap<>();
    static {
        PART_TO_BONE.put("body_mesh", "body");

        for (String part : new String[] {
            "head_mesh", "cheek_L_mesh", "cheek_R_mesh", "nose_mesh", "tear_L_mesh", "tear_R_mesh"
        }) {
            PART_TO_BONE.put(part, "head");
        }
        for (String part : new String[] {"lip_L_mesh", "lip_R_mesh", "mouth_inside_mesh"}) {
            PART_TO_BONE.put(part, "mouth");
        }

        for (String side : new String[] {"L", "R"}) {
            PART_TO_BONE.put("eyeball_" + side, "eyeball_" + side);
            PART_TO_BONE.put("eyelid_" + side, "eyelid_" + side);
            PART_TO_BONE.put("pupil_" + side, "pupil_dot_" + side);
            PART_TO_BONE.put("arm_" + side + "_mesh", "arm_" + side);
            PART_TO_BONE.put("palm_" + side + "_mesh", "paw_" + side);
            for (int i = 1; i <= 3; i++) {
                PART_TO_BONE.put("finger_" + side + i + "_mesh", "paw_" + side);
            }
        }
    }

    private static Map<String, float[]> quadsByBone = null;
    private static boolean attempted = false;

    private PipObjModel() {}

    /** Lazily loads the model on first use. Returns null if loading failed (error is logged once). */
    public static synchronized Map<String, float[]> getQuadsByBone() {
        if (!attempted) {
            attempted = true;
            try {
                quadsByBone = load();
                LOGGER.info("[piphorror] Loaded friendly Pip OBJ model ({} bones with geometry)", quadsByBone.size());
            } catch (Exception e) {
                LOGGER.error("[piphorror] Could not load {}", MODEL, e);
            }
        }
        return quadsByBone;
    }

    private static Map<String, float[]> load() throws IOException {
        List<float[]> positions = new ArrayList<>();
        List<float[]> uvs = new ArrayList<>();
        List<float[]> normals = new ArrayList<>();
        Map<String, FloatBuf> buffers = new HashMap<>();
        String bone = "body";

        try (InputStream in = Minecraft.getInstance().getResourceManager().open(MODEL);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.charAt(0) == '#') {
                    continue;
                }
                String[] t = line.split("\\s+");
                switch (t[0]) {
                    case "o", "g" -> {
                        String part = t.length > 1 ? t[1] : "";
                        bone = PART_TO_BONE.getOrDefault(part, "body");
                        if (!PART_TO_BONE.containsKey(part)) {
                            LOGGER.warn("[piphorror] OBJ part '{}' has no bone mapping, attaching to body", part);
                        }
                    }
                    case "v" -> positions.add(new float[] {
                        Float.parseFloat(t[1]), Float.parseFloat(t[2]), Float.parseFloat(t[3])
                    });
                    // OBJ has V=0 at the bottom, Minecraft has V=0 at the top.
                    case "vt" -> uvs.add(new float[] {
                        Float.parseFloat(t[1]), 1.0F - Float.parseFloat(t[2])
                    });
                    case "vn" -> normals.add(new float[] {
                        Float.parseFloat(t[1]), Float.parseFloat(t[2]), Float.parseFloat(t[3])
                    });
                    case "f" -> addFace(t, positions, uvs, normals,
                        buffers.computeIfAbsent(bone, k -> new FloatBuf()));
                    default -> { }
                }
            }
        }

        Map<String, float[]> result = new HashMap<>();
        for (Map.Entry<String, FloatBuf> e : buffers.entrySet()) {
            result.put(e.getKey(), e.getValue().toArray());
        }
        return result;
    }

    private static void addFace(String[] t, List<float[]> pos, List<float[]> uv, List<float[]> nor, FloatBuf out) {
        int n = t.length - 1;
        if (n < 3) {
            return;
        }
        float[][] verts = new float[n][FLOATS_PER_VERTEX];
        boolean hasNormals = true;
        for (int i = 0; i < n; i++) {
            String[] idx = t[i + 1].split("/", -1);
            float[] p = pos.get(resolve(idx[0], pos.size()));
            verts[i][0] = p[0];
            verts[i][1] = p[1];
            verts[i][2] = p[2];
            if (idx.length > 1 && !idx[1].isEmpty()) {
                float[] tc = uv.get(resolve(idx[1], uv.size()));
                verts[i][3] = tc[0];
                verts[i][4] = tc[1];
            }
            if (idx.length > 2 && !idx[2].isEmpty()) {
                float[] nn = nor.get(resolve(idx[2], nor.size()));
                verts[i][5] = nn[0];
                verts[i][6] = nn[1];
                verts[i][7] = nn[2];
            } else {
                hasNormals = false;
            }
        }

        if (!hasNormals) {
            float ax = verts[1][0] - verts[0][0], ay = verts[1][1] - verts[0][1], az = verts[1][2] - verts[0][2];
            float bx = verts[2][0] - verts[0][0], by = verts[2][1] - verts[0][1], bz = verts[2][2] - verts[0][2];
            float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
            float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len > 0.0F) {
                nx /= len;
                ny /= len;
                nz /= len;
            }
            for (float[] v : verts) {
                v[5] = nx;
                v[6] = ny;
                v[7] = nz;
            }
        }

        if (n == 4) {
            out.add(verts[0]);
            out.add(verts[1]);
            out.add(verts[2]);
            out.add(verts[3]);
        } else {
            // Fan-triangulate; every triangle becomes a quad with a repeated last vertex.
            for (int i = 1; i < n - 1; i++) {
                out.add(verts[0]);
                out.add(verts[i]);
                out.add(verts[i + 1]);
                out.add(verts[i + 1]);
            }
        }
    }

    /** OBJ indices are 1-based; negative indices count back from the end of the list. */
    private static int resolve(String token, int size) {
        int i = Integer.parseInt(token);
        return i > 0 ? i - 1 : size + i;
    }

    private static final class FloatBuf {
        private float[] data = new float[4096];
        private int size = 0;

        void add(float[] vertex) {
            if (size + vertex.length > data.length) {
                data = java.util.Arrays.copyOf(data, Math.max(data.length * 2, size + vertex.length));
            }
            System.arraycopy(vertex, 0, data, size, vertex.length);
            size += vertex.length;
        }

        float[] toArray() {
            return java.util.Arrays.copyOf(data, size);
        }
    }
}
