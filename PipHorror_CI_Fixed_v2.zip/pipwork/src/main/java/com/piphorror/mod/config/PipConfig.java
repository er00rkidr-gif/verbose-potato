package com.piphorror.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.loading.FMLPaths;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Configuration for Pip companion behavior and optional live AI chat replies.
 * File location inside Minecraft: config/piphorror-common.toml
 */
public class PipConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue PET_FOLLOW_ALWAYS;
    public static final ForgeConfigSpec.DoubleValue PET_FOLLOW_DISTANCE;
    public static final ForgeConfigSpec.BooleanValue AUTO_STALK_TREES;
    public static final ForgeConfigSpec.IntValue STALK_COOLDOWN_TICKS;

    public static final ForgeConfigSpec.BooleanValue AI_ENABLED;
    public static final ForgeConfigSpec.ConfigValue<String> AI_PROVIDER;
    public static final ForgeConfigSpec.ConfigValue<String> AI_API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> AI_MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> AI_BASE_URL;
    public static final ForgeConfigSpec.ConfigValue<String> AI_SYSTEM_PROMPT;
    public static final ForgeConfigSpec.IntValue AI_MAX_TOKENS;

    // Fallback cache when injected into a third-party mod whose @Mod class didn't register SPEC
    private static boolean fallbackLoaded = false;
    private static boolean fbFollowAlways = true;
    private static boolean fbAutoStalk = true;
    private static boolean fbAiEnabled = true;
    private static String fbProvider = "gemini";
    private static String fbApiKey = "";
    private static String fbModel = "gemini-2.5-flash";
    private static String fbBaseUrl = "";
    private static String fbSystemPrompt = "You are Pip, a cute yet eerie mint-and-lavender pet creature in Minecraft 1.20.1. Keep replies under 2 short sentences, stay loyal to your owner, and notice nearby trees, darkness, or mobs.";

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("companion");
        PET_FOLLOW_ALWAYS = builder
            .comment("If true, Pip automatically binds to you as your pet and follows you all the time.")
            .define("petFollowAlways", true);
        PET_FOLLOW_DISTANCE = builder
            .comment("Comfortable follow radius in blocks around the owner.")
            .defineInRange("followDistance", 4.0D, 2.0D, 16.0D);
        AUTO_STALK_TREES = builder
            .comment("If true, Pip occasionally hides behind the nearest tree trunk or wall and peeks out at you.")
            .define("autoStalkBehindTrees", true);
        STALK_COOLDOWN_TICKS = builder
            .comment("Ticks between autonomous tree/block cover stalking attempts (20 ticks = 1 second).")
            .defineInRange("stalkCooldownTicks", 560, 120, 6000);
        builder.pop();

        builder.push("ai");
        AI_ENABLED = builder
            .comment("Enable real AI chat replies when talking to Pip in Minecraft chat.")
            .define("enabled", true);
        AI_PROVIDER = builder
            .comment("AI API provider: \"gemini\" (Google AI Studio key) or \"openai\" (OpenAI-compatible endpoint).")
            .define("provider", "gemini");
        AI_API_KEY = builder
            .comment("Paste your Gemini (AIza...) or OpenAI (sk-...) API key here so Pip responds to you in chat.")
            .define("apiKey", "");
        AI_MODEL = builder
            .comment("Model name, e.g. gemini-2.5-flash or gpt-4o-mini.")
            .define("model", "gemini-2.5-flash");
        AI_BASE_URL = builder
            .comment("Optional custom API URL override (leave blank for default provider URL).")
            .define("apiBaseUrl", "");
        AI_SYSTEM_PROMPT = builder
            .comment("Personality prompt sent to the AI model.")
            .define("systemPrompt", "You are Pip, a cute yet eerie mint-and-lavender pet creature in Minecraft 1.20.1. Keep replies under 2 short sentences, stay loyal to your owner, and notice nearby trees, darkness, or mobs.");
        AI_MAX_TOKENS = builder
            .comment("Maximum tokens for Pip's chat reply.")
            .defineInRange("maxReplyTokens", 180, 40, 600);
        builder.pop();

        SPEC = builder.build();
    }

    public static synchronized void ensureLoaded() {
        if (SPEC.isLoaded()) {
            return;
        }
        if (fallbackLoaded) {
            return;
        }
        fallbackLoaded = true;
        try {
            Path cfgPath = FMLPaths.CONFIGDIR.get().resolve("piphorror-common.toml");
            if (!Files.exists(cfgPath)) {
                Files.createDirectories(cfgPath.getParent());
                String defaultToml =
                    "[companion]\n" +
                    "\tpetFollowAlways = true\n" +
                    "\tfollowDistance = 4.0\n" +
                    "\tautoStalkBehindTrees = true\n" +
                    "\tstalkCooldownTicks = 560\n\n" +
                    "[ai]\n" +
                    "\tenabled = true\n" +
                    "\tprovider = \"gemini\"\n" +
                    "\t# Paste your Gemini or OpenAI API key below so Pip responds in chat\n" +
                    "\tapiKey = \"\"\n" +
                    "\tmodel = \"gemini-2.5-flash\"\n" +
                    "\tapiBaseUrl = \"\"\n" +
                    "\tsystemPrompt = \"You are Pip, a cute yet eerie mint-and-lavender pet creature in Minecraft 1.20.1. Keep replies under 2 short sentences, stay loyal to your owner, and notice nearby trees, darkness, or mobs.\"\n" +
                    "\tmaxReplyTokens = 180\n";
                Files.writeString(cfgPath, defaultToml, StandardCharsets.UTF_8);
                return;
            }
            String text = Files.readString(cfgPath, StandardCharsets.UTF_8);
            fbFollowAlways = readBool(text, "petFollowAlways", fbFollowAlways);
            fbAutoStalk = readBool(text, "autoStalkBehindTrees", fbAutoStalk);
            fbAiEnabled = readBool(text, "enabled", fbAiEnabled);
            fbProvider = readString(text, "provider", fbProvider);
            fbApiKey = readString(text, "apiKey", fbApiKey);
            fbModel = readString(text, "model", fbModel);
            fbBaseUrl = readString(text, "apiBaseUrl", fbBaseUrl);
            fbSystemPrompt = readString(text, "systemPrompt", fbSystemPrompt);
        } catch (Exception ignored) {
        }
    }

    private static String readString(String toml, String key, String fallback) {
        Matcher m = Pattern.compile("(?m)^\\s*" + Pattern.quote(key) + "\\s*=\\s*\"([^\"]*)\"").matcher(toml);
        return m.find() ? m.group(1).trim() : fallback;
    }

    private static boolean readBool(String toml, String key, boolean fallback) {
        Matcher m = Pattern.compile("(?m)^\\s*" + Pattern.quote(key) + "\\s*=\\s*(true|false)").matcher(toml);
        return m.find() ? Boolean.parseBoolean(m.group(1)) : fallback;
    }

    public static boolean isPetFollowAlways() {
        ensureLoaded();
        return SPEC.isLoaded() ? PET_FOLLOW_ALWAYS.get() : fbFollowAlways;
    }

    public static double getFollowDistance() {
        ensureLoaded();
        return SPEC.isLoaded() ? PET_FOLLOW_DISTANCE.get() : 4.0D;
    }

    public static boolean isAutoStalkTrees() {
        ensureLoaded();
        return SPEC.isLoaded() ? AUTO_STALK_TREES.get() : fbAutoStalk;
    }

    public static int getStalkCooldownTicks() {
        ensureLoaded();
        return SPEC.isLoaded() ? STALK_COOLDOWN_TICKS.get() : 560;
    }

    public static boolean isAiEnabled() {
        ensureLoaded();
        return SPEC.isLoaded() ? AI_ENABLED.get() : fbAiEnabled;
    }

    public static String getApiKey() {
        ensureLoaded();
        return (SPEC.isLoaded() ? AI_API_KEY.get() : fbApiKey).trim();
    }

    public static String getProvider() {
        ensureLoaded();
        return (SPEC.isLoaded() ? AI_PROVIDER.get() : fbProvider).trim();
    }

    public static String getModel() {
        ensureLoaded();
        return (SPEC.isLoaded() ? AI_MODEL.get() : fbModel).trim();
    }

    public static String getBaseUrl() {
        ensureLoaded();
        return (SPEC.isLoaded() ? AI_BASE_URL.get() : fbBaseUrl).trim();
    }

    public static String getSystemPrompt() {
        ensureLoaded();
        return SPEC.isLoaded() ? AI_SYSTEM_PROMPT.get() : fbSystemPrompt;
    }

    public static boolean hasApiKey() {
        return !getApiKey().isBlank();
    }

    public static int getMaxTokens() {
        ensureLoaded();
        return SPEC.isLoaded() ? AI_MAX_TOKENS.get() : 180;
    }

    /**
     * Saves the AI settings made in the /pip gui screen to config/piphorror-common.toml.
     * A blank apiKey keeps the key that is already saved.
     */
    public static synchronized void saveAiSettings(boolean enabled, String provider, String apiKey, String model, String baseUrl) {
        ensureLoaded();
        String key = apiKey == null ? "" : apiKey.trim();
        if (SPEC.isLoaded()) {
            AI_ENABLED.set(enabled);
            AI_PROVIDER.set(provider.trim());
            if (!key.isEmpty()) {
                AI_API_KEY.set(key);
            }
            AI_MODEL.set(model.trim());
            AI_BASE_URL.set(baseUrl.trim());
            SPEC.save();
        } else {
            fbAiEnabled = enabled;
            fbProvider = provider.trim();
            if (!key.isEmpty()) {
                fbApiKey = key;
            }
            fbModel = model.trim();
            fbBaseUrl = baseUrl.trim();
            try {
                Path cfgPath = FMLPaths.CONFIGDIR.get().resolve("piphorror-common.toml");
                String toml = "[companion]\n\tpetFollowAlways = " + fbFollowAlways + "\n\tfollowDistance = 4.0\n"
                    + "\tautoStalkBehindTrees = " + fbAutoStalk + "\n\tstalkCooldownTicks = 560\n\n[ai]\n"
                    + "\tenabled = " + fbAiEnabled + "\n\tprovider = \"" + fbProvider + "\"\n"
                    + "\tapiKey = \"" + fbApiKey.replace("\"", "") + "\"\n\tmodel = \"" + fbModel + "\"\n"
                    + "\tapiBaseUrl = \"" + fbBaseUrl + "\"\n"
                    + "\tsystemPrompt = \"" + fbSystemPrompt.replace("\"", "'") + "\"\n\tmaxReplyTokens = 180\n";
                Files.writeString(cfgPath, toml, StandardCharsets.UTF_8);
            } catch (Exception ignored) {
            }
        }
    }
}
